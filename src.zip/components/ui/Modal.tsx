import React, { useEffect, useId, useRef } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../utils/cn';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  /** Description lisible par les SR. Si non fourni, on injecte un fallback “sr-only”. */
  description?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  description,
  children,
  size = 'md',
}) => {
  const titleId = useId();
  const descId = useId();
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      // focus le contenu pour SR/keyboard
      setTimeout(() => panelRef.current?.focus(), 0);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4">
        <div
          className="fixed inset-0 bg-black bg-opacity-50 transition-opacity"
          onClick={onClose}
          aria-hidden="true"
        />
        <div
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby={title ? titleId : undefined}
          aria-describedby={descId}
          tabIndex={-1}
          className={cn(
            'relative w-full bg-white rounded-lg shadow-xl transform transition-all outline-none',
            sizeClasses[size]
          )}
        >
          <div className="flex items-center justify-between p-6 border-b">
            {title ? (
              <h3 id={titleId} className="text-lg font-semibold text-gray-900">
                {title}
              </h3>
            ) : (
              // Titre caché si pas fourni (équiv. VisuallyHidden)
              <h3 id={titleId} className="sr-only">
                Dialogue
              </h3>
            )}

            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Fermer la fenêtre"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Description accessible (affichée si fournie, sinon cachée) */}
          {description ? (
            <p id={descId} className="sr-only">
              {description}
            </p>
          ) : (
            <p id={descId} className="sr-only">
              Fenêtre de dialogue. Remplissez le formulaire et validez.
            </p>
          )}

          <div className="p-6">{children}</div>
        </div>
      </div>
    </div>
  );
};
