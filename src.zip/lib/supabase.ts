// src/lib/supabase.ts
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!url || !anonKey) {
  console.error('❌ VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY manquants');
}

console.log('🔧 Configuration Supabase PRODUCTION:', {
  url,
  keyLength: anonKey?.length ?? 0,
  environment: 'production',
});

export const supabase: SupabaseClient = createClient(url, anonKey);
console.log('✅ Client Supabase créé avec succès');

// -------- utils --------
const nilIfEmpty = (v: any) => (v === '' || v === undefined ? null : v);

const normalizeOwner = (o: any) => ({
  first_name:     nilIfEmpty(o.firstName ?? o.first_name),
  last_name:      nilIfEmpty(o.lastName  ?? o.last_name),
  phone:          nilIfEmpty(o.phone),
  email:          nilIfEmpty(o.email),
  city:           nilIfEmpty(o.city),
  marital_status: nilIfEmpty(o.maritalStatus ?? o.marital_status),
});

const normalizeTenant = (t: any) => ({
  first_name: nilIfEmpty(t.firstName ?? t.first_name),
  last_name:  nilIfEmpty(t.lastName  ?? t.last_name),
  phone:      nilIfEmpty(t.phone),
  email:      nilIfEmpty(t.email),
  city:       nilIfEmpty(t.city),
});

const normalizeProperty = (p: any) => ({
  title: nilIfEmpty(p.title ?? p.propertyTitle),
  city:  nilIfEmpty(p.city),
});

function formatSbError(prefix: string, error: any) {
  const parts = [prefix];
  if (error?.code) parts.push(`code=${error.code}`);
  if (error?.message) parts.push(`msg=${error.message}`);
  if (error?.details) parts.push(`details=${error.details}`);
  if (error?.hint) parts.push(`hint=${error.hint}`);
  return parts.join(' | ');
}

async function logAuthContext(tag: string) {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) {
      console.warn(`🔑 ${tag} auth.getSession error:`, error);
      return;
    }
    console.log(`🔑 ${tag} user:`, session?.user?.id ?? null, 'token?', !!session?.access_token);
  } catch (e) {
    console.warn(`🔑 ${tag} auth.getSession threw:`, e);
  }
}

function isRlsDenied(err: any): boolean {
  const code = err?.code || '';
  const msg = (err?.message || '').toLowerCase();
  return code === '42501' || msg.includes('row-level security') || msg.includes('permission denied');
}

// -------- fallback API (Service Role côté serveur) --------
async function createOwnerViaApi(cleanOwner: any) {
  const { data: { session } } = await supabase.auth.getSession();
  const user = session?.user;
  const secret = import.meta.env.VITE_DEMO_SHARED_SECRET as string | undefined;

  if (!secret) throw new Error('fallback_disabled: VITE_DEMO_SHARED_SECRET manquant');

  const resp = await fetch('/api/owners/create', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // 🔒 ce secret doit correspondre à DEMO_SHARED_SECRET défini dans Vercel (server)
      Authorization: `Bearer ${secret}`,
    },
    body: JSON.stringify({
      owner: cleanOwner,
      userEmail: user?.email ?? null,
      userId: user?.id ?? null,
    }),
  });

  if (!resp.ok) {
    let out = 'fallback_api_failed';
    try { const j = await resp.json(); out = j.error || out; } catch {}
    throw new Error(out);
  }

  return await resp.json();
}

// ---------- CONSTANTES ----------
const LOCAL_STORAGE_KEY = "agency_registration_requests";

// ======================================================
// ================   DB SERVICE   ======================
// ======================================================

// ---------- STATS PLATEFORME (ADMIN GLOBAL) ----------
async getPlatformStats() {
  const tables = [
    'agency_registration_requests',
    'agencies',
    'agency_users',
    'owners',
    'tenants',
    'properties',
    'contracts',
  ] as const;

  const counts: Record<string, number> = {};
  for (const t of tables) {
    const { count, error } = await supabase
      .from(t)
      .select('id', { count: 'exact', head: true });
    counts[t] = error ? 0 : (count ?? 0);
  }

  const { count: pending } = await supabase
    .from('agency_registration_requests')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'pending');

  const { count: approved } = await supabase
    .from('agency_registration_requests')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'approved');

  return {
    requests_total: counts['agency_registration_requests'],
    requests_pending: pending ?? 0,
    requests_approved: approved ?? 0,
    agencies_total: counts['agencies'],
    users_total: counts['agency_users'],
    owners_total: counts['owners'],
    tenants_total: counts['tenants'],
    properties_total: counts['properties'],
    contracts_total: counts['contracts'],
    generated_at: new Date().toISOString(),
  };
},

// ---------- SUBSCRIPTIONS (ADMIN) ----------
async getAllSubscriptions() {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .order('created_at', { ascending: false });

  // si la table n'existe pas, on retourne un tableau vide proprement
  if (error && (error.code === '42P01' || /does not exist/i.test(error.message))) {
    console.warn('ℹ️ Table "subscriptions" absente — retourne [].');
    return [];
  }
  if (error) throw new Error(formatSbError('❌ subscriptions.select', error));
  return data ?? [];
},


export const dbService = {
  // ---------- AGENCY REGISTRATION (utilisé par AgencyRegistration.tsx) ----------
  async createRegistrationRequest(req: any) {
    await logAuthContext('agency_registration_requests.insert');

    // Nettoyage/normalisation des champs attendus par la table
    const clean = {
      agency_name:          nilIfEmpty(req.agency_name),
      commercial_register:  nilIfEmpty(req.commercial_register),
      director_first_name:  nilIfEmpty(req.director_first_name),
      director_last_name:   nilIfEmpty(req.director_last_name),
      director_email:       nilIfEmpty(req.director_email),
      phone:                nilIfEmpty(req.phone),
      city:                 nilIfEmpty(req.city),
      address:              nilIfEmpty(req.address),
      logo_url:             nilIfEmpty(req.logo_url),
      is_accredited:        !!req.is_accredited,
      accreditation_number: nilIfEmpty(req.accreditation_number),
      status:               req.status ?? 'pending',
      // created_at: laissé au DEFAULT côté DB si présent
    };

    console.log('🔄 PRODUCTION - Création demande agence (payload):', clean);

    try {
      const { data, error } = await supabase
        .from('agency_registration_requests')
        .insert(clean)
        .select('id')
        .maybeSingle();

      if (error) throw error;

      const id = data?.id ?? null;
      console.log('✅ Demande agence créée id:', id);
      return { id };
    } catch (error) {
      console.warn('⚠️ createRegistrationRequest échoué, fallback localStorage:', error);
      // ---- fallback localStorage ----
      const localRequests = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || "[]");
      const localId = `local_${Date.now()}`;
      localRequests.push({ ...clean, id: localId, created_at: new Date().toISOString() });
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(localRequests));
      return { id: localId, local: true };
    }
  },

  // ---------- AGENCY REQUESTS (ADMIN) ----------
async getAllRegistrationRequests() {
  // Récupère TOUTES les demandes, triées des plus récentes aux plus anciennes
  const { data, error } = await supabase
    .from('agency_registration_requests')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(formatSbError('❌ agency_registration_requests.select', error));
  return data ?? [];
},

// Option 1 (recommandée): approbation via RPC (si tu as créé la fonction SQL)
async approveAgencyRequestViaRpc(requestId: string) {
  const { data, error } = await supabase
    .rpc('approve_agency_request', { p_request_id: requestId });

  if (error) throw new Error(formatSbError('❌ approve_agency_request RPC', error));
  return data;
},

// Option 2 (sans RPC): approbation en 3 étapes depuis le front
// (OK car RLS désactivé ; si tu réactives RLS, préfère la RPC SECURITY DEFINER)
async approveAgencyRequestDirect(requestId: string) {
  // 1) Charger la demande
  const { data: req, error: e1 } = await supabase
    .from('agency_registration_requests')
    .select('*')
    .eq('id', requestId)
    .maybeSingle();
  if (e1) throw new Error(formatSbError('❌ load request', e1));
  if (!req) throw new Error(`demande introuvable: ${requestId}`);

  // 2) Créer/MàJ l’agence
  const payloadAgency = {
    name: req.agency_name,
    commercial_register: req.commercial_register,
    phone: req.phone,
    email: req.director_email,
    address: req.address,
    city: req.city,
    is_accredited: !!req.is_accredited,
    accreditation_number: req.accreditation_number ?? null,
    status: 'approved',
  };

  const { data: agencyRow, error: e2 } = await supabase
    .from('agencies')
    .upsert(payloadAgency, { onConflict: 'commercial_register' })
    .select('*')
    .maybeSingle();
  if (e2) throw new Error(formatSbError('❌ upsert agency', e2));
  if (!agencyRow) throw new Error('upsert agency returned empty');

  // 3) Créer/activer le directeur dans agency_users
  const director = {
    agency_id: agencyRow.id,
    email: req.director_email,
    first_name: req.director_first_name,
    last_name: req.director_last_name,
    role: 'director',
    is_active: true,
  };

  const { error: e3 } = await supabase
    .from('agency_users')
    .upsert(director, { onConflict: 'agency_id,email' });
  if (e3) throw new Error(formatSbError('❌ upsert agency_user', e3));

  // 4) Marquer la demande approuvée
  const { error: e4 } = await supabase
    .from('agency_registration_requests')
    .update({ status: 'approved', approved_at: new Date().toISOString(), agency_id: agencyRow.id })
    .eq('id', requestId);
  if (e4) throw new Error(formatSbError('❌ update request status', e4));

  return { status: 'approved', agency_id: agencyRow.id, agency_name: agencyRow.name };
},


  // Synchronisation des enregistrements locaux → Supabase
  async syncLocalRequests(onSync?: (msg: string, success: boolean) => void) {
    const localRequests = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || "[]");
    if (!localRequests.length) return;

    for (const req of localRequests) {
      try {
        const { error } = await supabase
          .from("agency_registration_requests")
          .insert(req);

        if (error) throw error;

        // suppression de la requête locale
        const updated = localRequests.filter((r: any) => r.id !== req.id);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));

        onSync?.("✅ Synchronisation réussie avec le serveur", true);
      } catch (err) {
        console.error("⛔ Échec synchro:", err);
        onSync?.("⚠️ Erreur de synchro : certaines données restent en local", false);
      }
    }
  },

  // ---------- READ (RLS-only) ----------
  async getOwners() {
    const { data, error } = await supabase
      .from('owners')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async getTenants() {
    const { data, error } = await supabase
      .from('tenants')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async getProperties() {
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async getContracts() {
    const { data, error } = await supabase
      .from('contracts')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  // ---------- CREATE ----------
  async createOwner(owner: any) {
    await logAuthContext('owners.insert');

    // ⚠️ on ne transmet JAMAIS agency_id depuis le front
    const norm = normalizeOwner(owner);
    const { agency_id: _a, agency: _b, agencyId: _c, ...clean } = { ...owner, ...norm };

    console.log('🔄 PRODUCTION - Création propriétaire (payload):', clean);

    // 1) tentative directe (si session + RLS OK)
    const { data: direct, error } = await supabase
      .from('owners')
      .insert(clean)
      .select('*')
      .single();

    if (!error && direct) return direct;

    console.error('❌ owners.insert RAW:', error);
    if (!isRlsDenied(error)) throw new Error(formatSbError('❌ owners.insert', error));

    console.warn('↪️ RLS a bloqué, fallback API');
    return await createOwnerViaApi(clean);
  },

  async createTenant(tenant: any) {
    await logAuthContext('tenants.insert');
    const norm = normalizeTenant(tenant);
    const { agency_id: _a, agency: _b, agencyId: _c, ...clean } = { ...tenant, ...norm };

    console.log('🔄 PRODUCTION - Création locataire (payload):', clean);
    const { error } = await supabase.from('tenants').insert(clean);
    if (error) throw new Error(formatSbError('❌ tenants.insert', error));
    return true;
  },

  async createProperty(property: any) {
    await logAuthContext('properties.insert');
    const norm = normalizeProperty(property);
    const { agency_id: _a, agency: _b, agencyId: _c, ...clean } = { ...property, ...norm };

    console.log('🔄 PRODUCTION - Création propriété (payload):', clean);
    const { error } = await supabase.from('properties').insert(clean);
    if (error) throw new Error(formatSbError('❌ properties.insert', error));
    return true;
  },

  async createContract(contract: any) {
    await logAuthContext('contracts.insert');
    const { agency_id: _a, agency: _b, agencyId: _c, ...clean } = { ...contract };

    console.log('🔄 PRODUCTION - Création contrat (payload):', clean);
    const { error } = await supabase.from('contracts').insert(clean);
    if (error) throw new Error(formatSbError('❌ contracts.insert', error));
    return true;
  },

  // ---------- DELETE ----------
  async deleteOwner(id: string) {
    const { error } = await supabase.from('owners').delete().eq('id', id);
    if (error) throw new Error(formatSbError('❌ owners.delete', error));
    return true;
  },

  async deleteTenant(id: string) {
    const { error } = await supabase.from('tenants').delete().eq('id', id);
    if (error) throw new Error(formatSbError('❌ tenants.delete', error));
    return true;
  },

  async deleteProperty(id: string) {
    const { error } = await supabase.from('properties').delete().eq('id', id);
    if (error) throw new Error(formatSbError('❌ properties.delete', error));
    return true;
  },

  async deleteContract(id: string) {
    const { error } = await supabase.from('contracts').delete().eq('id', id);
    if (error) throw new Error(formatSbError('❌ contracts.delete', error));
    return true;
  },
};
