import React, { useEffect, useId } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../utils/cn';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  /** Texte descriptif optionnel pour aria-describedby (supprime le warning Radix-like) */
  description?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  description="Formulaire d'inscription d'agence",
  children,
  size = 'md',
}) => {
  const titleId = useId();
  const descId = useId();

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : 'unset';
    return () => { document.body.style.overflow = 'unset'; };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? titleId : undefined}
      aria-describedby={description ? descId : undefined}
    >
      <div className="flex min-h-full items-center justify-center p-4">
        <div
          className="fixed inset-0 bg-black/50 transition-opacity"
          onClick={onClose}
        />
        <div
          className={cn(
            'relative w-full bg-white rounded-lg shadow-xl transform transition-all',
            sizeClasses[size]
          )}
        >
          <div className="flex items-center justify-between p-6 border-b">
            {title ? (
              <h3 id={titleId} className="text-lg font-semibold text-gray-900">
                {title}
              </h3>
            ) : (
              // Fallback “visually hidden” si pas de titre
              <span id={titleId} className="sr-only">Dialog</span>
            )}
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Fermer la fenêtre"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Description cachée si fournie (évite le warning “Missing Description”) */}
          {description && (
            <p id={descId} className="sr-only">
              {description}
            </p>
          )}

          <div className="p-6">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
